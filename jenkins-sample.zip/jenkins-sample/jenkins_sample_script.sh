printenv
echo "This is simple command in Jenkins Job"
echo $USER
echo $PATH
echo $BUILD_NUMBER
echo $JOB_NAME
echo "User has selected Region as $REGION_CHOICE"
echo "User has selected Env as $ENV_CHOICE"
echo "User has selected Env as $ENV_CHOICE"
